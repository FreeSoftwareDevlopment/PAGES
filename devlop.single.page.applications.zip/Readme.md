# Publish Data from a build from Single page applications 

you have to save the build in the `data` folder (delete the test build from the existing data before) and then start the command `npm start` in the start directory
