const express = require('express');
const app = express();
const fs = require ('fs');
const files = 'data';
const indexhtml = 'index.html';
const data = fs.readFileSync(files + '/' + indexhtml);
app.use(express.static(__dirname + '/' + files));
app.get('/*', (request, response) => {
    response.set({
        'Content-Type': 'text/html'
    });
    response.send(data);
});
app.listen(80, () => {
  console.log("Online on port 80");
});
